package com.example.greenstudentportal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class Facebook extends AppCompatActivity {

    WebView webwiew3;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facebook);



        webwiew3 = findViewById(R.id.webwiew3);

        webwiew3.setWebViewClient(new WebViewClient());
        webwiew3.loadUrl("https://www.facebook.com/mr.mawdud/");
        WebSettings webSettings = webwiew3.getSettings();
        webSettings.setJavaScriptEnabled(true);


        getSupportActionBar().setDisplayShowHomeEnabled(true);
//     getSupportActionBar().setLogo(R.drawable.gub);
        getSupportActionBar().setTitle("Facebook");
        getSupportActionBar().setDisplayUseLogoEnabled(true);

    }

    private class MywebClient extends WebViewClient{
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return super.shouldOverrideUrlLoading(view, request);
        }
    }
    @Override
    public void onBackPressed() {
        if(webwiew3.isFocused() && webwiew3.canGoBack())
        {
            webwiew3.goBack();
        }else{
            super.onBackPressed();
        }
    }





}
