package com.example.greenstudentportal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;


public class greenweb extends AppCompatActivity {
    WebView webView2;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater =getMenuInflater();
        inflater.inflate(R.menu.for_uniweb,menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {


            case R.id.item1:
                Toast.makeText(this, "Student Portal is opened", Toast.LENGTH_SHORT).show();
                Intent i =new Intent(greenweb.this,MainActivity.class);
                startActivity(i);
                finish();
                return true;


        }
        return super.onOptionsItemSelected(item);
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Green University");
        getSupportActionBar().setDisplayUseLogoEnabled(true);



        webView2 = findViewById(R.id.webwiew);

        webView2.setWebViewClient(new WebViewClient());
        webView2.loadUrl("https://green.edu.bd/");
        WebSettings webSettings = webView2.getSettings();
        webSettings.setJavaScriptEnabled(true);




    }

    private class MywebClient extends WebViewClient{
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return super.shouldOverrideUrlLoading(view, request);
        }
    }
    @Override
    public void onBackPressed() {
        if(webView2.isFocused() && webView2.canGoBack())
        {
            webView2.goBack();
        }else{
            super.onBackPressed();
        }
    }





}
