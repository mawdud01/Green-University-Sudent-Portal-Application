package com.example.greenstudentportal;


import androidx.annotation.NonNull;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    WebView webView;


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater =getMenuInflater();
        inflater.inflate(R.menu.example_menu,menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {


            case R.id.item1:
                Toast.makeText(this, "University Website is opened", Toast.LENGTH_SHORT).show();
                Intent i =new Intent(MainActivity.this,greenweb.class);
                startActivity(i);
                finish();
                return true;

            case R.id.item2:

                Toast.makeText(this, "ধন্যবাদ আবার আসবেন", Toast.LENGTH_SHORT).show();
                finish();
                System.exit(0);
                return true;

            case R.id.item3:

                Intent i2 =new Intent(MainActivity.this,feedback.class);
                startActivity(i2);
                finish();
                return true;

        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        getSupportActionBar().setDisplayShowHomeEnabled(true);
//     getSupportActionBar().setLogo(R.drawable.gub);
        getSupportActionBar().setTitle(" Student Portal");
        getSupportActionBar().setDisplayUseLogoEnabled(true);




        webView = findViewById(R.id.webwiew);

        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://studentportal.green.edu.bd/Account/login?ReturnUrl=%2F");
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

    }

    private class MywebClient extends WebViewClient{
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return super.shouldOverrideUrlLoading(view, request);
        }
    }
    @Override
    public void onBackPressed() {
        if(webView.isFocused() && webView.canGoBack())
        {
            webView.goBack();
        }else{
            super.onBackPressed();
        }
    }





}
